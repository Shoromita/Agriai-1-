# AgriAI — Authentication + Database

Authentication-only slice of AgriAI: signup, login, forgot/reset password,
and a Mongoose `User` profile store. No other features are included.

Two client options are provided; both talk to the same `/server` backend.

## Structure

```
client/   React web app (Vite, Tailwind, React Router, Axios, Firebase Auth)
mobile/   React Native phone app (Expo, React Navigation, Firebase Auth) — see mobile/README.md
server/   Express API (firebase-admin token verification, Mongoose/MongoDB)
```

If you want the phone app, jump to **`mobile/README.md`** for Expo-specific
setup (it covers the one tricky part: deep-linking the password-reset email
back into the app).

## Setup

### 1. Firebase project
- Create a project at https://console.firebase.google.com
- Enable **Authentication > Sign-in method > Email/Password**
- Under **Project Settings > General**, copy the web app config into `client/.env`
- Under **Project Settings > Service Accounts**, generate a private key JSON
  file, save it in `server/`, and point `FIREBASE_ADMIN_KEY_PATH` at it
- Under **Authentication > Templates > Password reset**, set the action URL
  to `http://localhost:3000/reset-password` (and your production URL later)
  so the emailed link opens the Reset Password page in this app

### 2. Client
```bash
cd client
cp .env.example .env   # fill in Firebase web config
npm install
npm run dev             # http://localhost:3000
```

### 3. Server
```bash
cd server
cp .env.example .env    # set MONGODB_URI and FIREBASE_ADMIN_KEY_PATH
npm install
npm run dev              # http://localhost:5000
```

Make sure MongoDB is running locally (or point `MONGODB_URI` at Atlas).

## Auth flow

1. **Signup** creates the user in Firebase, then calls
   `POST /api/auth/register` with the Firebase ID token to save a matching
   profile (`name`, `email`, `role`) in MongoDB.
2. **Login** signs in with Firebase; wrong credentials show one message
   with an inline "Reset your password" link.
3. **Forgot password** sends a Firebase reset email.
4. **Reset password** reads `oobCode` from the emailed link's URL and calls
   `confirmPasswordReset`.
5. `AuthProvider` / `useAuth()` track the session; `ProtectedRoute` guards
   `/dashboard` (a placeholder page proving the flow works end-to-end).
6. `GET /api/auth/me` returns the caller's MongoDB profile, protected by
   the `verifyToken` middleware (checks the Firebase ID token via
   `firebase-admin`).

All Firebase error codes are translated to plain-language messages in
`client/src/utils/authErrors.js` — raw codes are never shown to the user.
