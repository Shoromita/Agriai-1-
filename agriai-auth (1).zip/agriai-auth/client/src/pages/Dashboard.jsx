import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../api/axios';

// Placeholder landing page after login. Confirms the auth flow works end to
// end by fetching the MongoDB profile via GET /api/auth/me.
// AgriAI's real features (disease detection, weather, market prices) are out
// of scope for this build.
export default function Dashboard() {
  const { currentUser, logout } = useAuth();
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api
      .get('/auth/me')
      .then((res) => setProfile(res.data))
      .catch(() => setError('Could not load your profile.'));
  }, []);

  return (
    <div className="min-h-screen bg-green-50 flex items-center justify-center px-4">
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 max-w-md w-full text-center">
        <h1 className="text-xl font-semibold text-gray-900 mb-2">
          Welcome, {currentUser?.displayName || currentUser?.email}
        </h1>
        {profile && (
          <p className="text-sm text-gray-500 mb-4">
            Signed in as <span className="font-medium">{profile.role}</span>
          </p>
        )}
        {error && <p className="text-sm text-red-600 mb-4">{error}</p>}
        <button
          onClick={logout}
          className="bg-gray-800 hover:bg-gray-900 text-white text-sm font-medium rounded-lg px-4 py-2"
        >
          Log out
        </button>
      </div>
    </div>
  );
}
