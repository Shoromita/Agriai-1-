import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { friendlyAuthError } from '../utils/authErrors';
import AuthCard from '../components/AuthCard';

export default function ForgotPassword() {
  const { resetPassword } = useAuth();
  const location = useLocation();

  const [email, setEmail] = useState(location.state?.email || '');
  const [error, setError] = useState('');
  const [sent, setSent] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    try {
      await resetPassword(email);
      setSent(true);
    } catch (err) {
      // Don't reveal whether the email exists in the system.
      setSent(true);
      void friendlyAuthError(err);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <AuthCard title="Reset your password" subtitle="We'll email you a link to choose a new one">
      {sent ? (
        <div className="text-center space-y-4">
          <div className="text-sm text-green-800 bg-green-50 border border-green-100 rounded-lg px-3 py-3">
            If an account exists for <span className="font-medium">{email}</span>, a reset link
            has been sent. Check your inbox (and spam folder).
          </div>
          <Link to="/login" className="text-green-700 font-medium hover:underline text-sm">
            Back to login
          </Link>
        </div>
      ) : (
        <>
          {error && (
            <div className="mb-4 text-sm text-red-700 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
              {error}
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="you@example.com"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-green-600 hover:bg-green-700 disabled:bg-green-300 text-white font-medium rounded-lg py-2.5 transition-colors"
            >
              {submitting ? 'Sending link...' : 'Send reset link'}
            </button>
          </form>

          <p className="text-sm text-gray-500 text-center mt-6">
            Remembered it?{' '}
            <Link to="/login" className="text-green-700 font-medium hover:underline">
              Back to login
            </Link>
          </p>
        </>
      )}
    </AuthCard>
  );
}
