const admin = require('firebase-admin');
const path = require('path');

// Path to the Firebase service account JSON key file, set via env var.
// Get this from Firebase Console > Project Settings > Service Accounts.
const serviceAccountPath = process.env.FIREBASE_ADMIN_KEY_PATH;

if (!serviceAccountPath) {
  throw new Error('FIREBASE_ADMIN_KEY_PATH is not set in the environment');
}

const serviceAccount = require(path.resolve(serviceAccountPath));

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

module.exports = admin;
