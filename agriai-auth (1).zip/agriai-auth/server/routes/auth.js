const express = require('express');
const User = require('../models/User');
const verifyToken = require('../middleware/verifyToken');

const router = express.Router();

// POST /api/auth/register
// Called right after Firebase sign-up on the client. Verifies the Firebase
// ID token, then creates (or upserts) the matching MongoDB profile.
router.post('/register', verifyToken, async (req, res) => {
  const { name, email, role } = req.body;
  const { uid, email: tokenEmail } = req.firebaseUser;

  if (!name || !role) {
    return res.status(400).json({ message: 'Name and role are required.' });
  }
  if (!['farmer', 'admin'].includes(role)) {
    return res.status(400).json({ message: 'Role must be "farmer" or "admin".' });
  }

  try {
    let user = await User.findOne({ firebaseUid: uid });

    if (user) {
      return res.status(200).json(user);
    }

    user = await User.create({
      firebaseUid: uid,
      name,
      email: email || tokenEmail,
      role,
    });

    return res.status(201).json(user);
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ message: 'A profile for this account already exists.' });
    }
    console.error('Error creating user profile:', err);
    return res.status(500).json({ message: 'Could not create user profile.' });
  }
});

// GET /api/auth/me
// Returns the logged-in user's MongoDB profile. Protected by verifyToken.
router.get('/me', verifyToken, async (req, res) => {
  try {
    const user = await User.findOne({ firebaseUid: req.firebaseUser.uid });

    if (!user) {
      return res.status(404).json({ message: 'User profile not found.' });
    }

    return res.status(200).json(user);
  } catch (err) {
    console.error('Error fetching user profile:', err);
    return res.status(500).json({ message: 'Could not fetch user profile.' });
  }
});

module.exports = router;
