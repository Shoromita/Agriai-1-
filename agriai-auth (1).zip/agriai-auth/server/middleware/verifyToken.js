const admin = require('../firebaseAdmin');

// Verifies the Firebase ID token sent as "Authorization: Bearer <token>".
// On success, attaches the decoded token (uid, email, etc.) to req.firebaseUser.
async function verifyToken(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const [scheme, token] = authHeader.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ message: 'Missing or malformed authorization header.' });
  }

  try {
    const decodedToken = await admin.auth().verifyIdToken(token);
    req.firebaseUser = decodedToken;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid or expired authentication token.' });
  }
}

module.exports = verifyToken;
