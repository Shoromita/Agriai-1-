// Maps Firebase Auth error codes to friendly, user-facing text.
// Never show raw codes like "auth/invalid-credential" to the user.
export function friendlyAuthError(error) {
  const code = error?.code || '';

  switch (code) {
    case 'auth/invalid-email':
      return "That email address doesn't look right.";
    case 'auth/user-disabled':
      return 'This account has been disabled. Contact support for help.';
    case 'auth/user-not-found':
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'WRONG_CREDENTIALS'; // handled specially by the Login screen (adds reset link)
    case 'auth/email-already-in-use':
      return 'An account with this email already exists. Try logging in instead.';
    case 'auth/weak-password':
      return 'Please choose a stronger password (at least 6 characters).';
    case 'auth/too-many-requests':
      return 'Too many attempts. Please wait a moment and try again.';
    case 'auth/network-request-failed':
      return 'Network error. Check your connection and try again.';
    case 'auth/expired-action-code':
      return 'This password reset link has expired. Please request a new one.';
    case 'auth/invalid-action-code':
      return 'This password reset link is invalid or has already been used.';
    default:
      return 'Something went wrong. Please try again.';
  }
}
