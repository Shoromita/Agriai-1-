import { initializeApp } from 'firebase/app';
import { initializeAuth, getReactNativePersistence } from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';

// Values come from app.config.js -> extra (see .env.example)
const { firebase: firebaseConfig } = Constants.expoConfig.extra;

const app = initializeApp(firebaseConfig);

// React Native has no window.localStorage, so Firebase Auth needs an
// explicit persistence layer backed by AsyncStorage to stay logged in
// between app launches.
export const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage),
});

export default app;
