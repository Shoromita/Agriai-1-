import { View, ActivityIndicator } from 'react-native';
import { useAuth } from '../context/AuthContext';
import AuthNavigator from './AuthNavigator';
import AppNavigator from './AppNavigator';
import { colors, styles } from '../styles';

// This is the mobile equivalent of the web app's ProtectedRoute: instead of
// redirecting, it swaps the entire navigator based on whether currentUser
// exists. Screens inside AppNavigator are simply unreachable while logged out.
export default function RootNavigator() {
  const { currentUser, loading } = useAuth();

  if (loading) {
    return (
      <View style={[styles.screen, { alignItems: 'center', justifyContent: 'center' }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return currentUser ? <AppNavigator /> : <AuthNavigator />;
}
