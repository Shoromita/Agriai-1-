import axios from 'axios';
import Constants from 'expo-constants';
import { auth } from '../firebase';

const { apiBaseUrl } = Constants.expoConfig.extra;

const api = axios.create({
  baseURL: apiBaseUrl, // e.g. http://192.168.1.20:5000/api — see README for why localhost won't work on a device
});

api.interceptors.request.use(async (config) => {
  const currentUser = auth.currentUser;
  if (currentUser) {
    const token = await currentUser.getIdToken();
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;
