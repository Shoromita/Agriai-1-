import { StyleSheet } from 'react-native';

// A simple, clean, farming-green palette shared by every auth screen.
export const colors = {
  background: '#F0FDF4',
  primary: '#16A34A',
  primaryDark: '#15803D',
  primaryDisabled: '#86EFAC',
  text: '#111827',
  subtext: '#6B7280',
  border: '#D1D5DB',
  errorBg: '#FEF2F2',
  errorBorder: '#FECACA',
  errorText: '#B91C1C',
  successBg: '#F0FDF4',
  successBorder: '#BBF7D0',
  successText: '#166534',
};

export const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 24,
  },
  logoBadge: {
    alignSelf: 'center',
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  logoText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '700',
  },
  title: {
    fontSize: 22,
    fontWeight: '600',
    color: colors.text,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    color: colors.subtext,
    textAlign: 'center',
    marginTop: 4,
    marginBottom: 24,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#F3F4F6',
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  label: {
    fontSize: 13,
    fontWeight: '500',
    color: '#374151',
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 15,
    color: colors.text,
    marginBottom: 16,
  },
  pickerWrapper: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 10,
    marginBottom: 16,
    overflow: 'hidden',
  },
  button: {
    backgroundColor: colors.primary,
    borderRadius: 10,
    paddingVertical: 13,
    alignItems: 'center',
  },
  buttonDisabled: {
    backgroundColor: colors.primaryDisabled,
  },
  buttonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
  },
  linkRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  linkRowEnd: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: 16,
  },
  bodyText: {
    fontSize: 14,
    color: colors.subtext,
  },
  linkText: {
    fontSize: 14,
    color: colors.primaryDark,
    fontWeight: '600',
  },
  banner: {
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 16,
  },
  bannerError: {
    backgroundColor: colors.errorBg,
    borderColor: colors.errorBorder,
  },
  bannerErrorText: {
    color: colors.errorText,
    fontSize: 13,
    lineHeight: 19,
  },
  bannerSuccess: {
    backgroundColor: colors.successBg,
    borderColor: colors.successBorder,
  },
  bannerSuccessText: {
    color: colors.successText,
    fontSize: 13,
    lineHeight: 19,
    textAlign: 'center',
  },
});
