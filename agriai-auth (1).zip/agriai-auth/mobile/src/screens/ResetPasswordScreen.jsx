import { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { friendlyAuthError } from '../utils/authErrors';
import { styles } from '../styles';

export default function ResetPasswordScreen({ navigation, route }) {
  const { completePasswordReset } = useAuth();

  // Firebase's reset email deep-links back into the app as something like:
  // agriai://reset-password?oobCode=XXXX&mode=resetPassword
  // React Navigation's linking config (see App.js) turns that into route params.
  const oobCode = route.params?.oobCode;

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit() {
    setError('');

    if (!oobCode) {
      setError('This reset link is invalid or has expired. Please request a new one.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setSubmitting(true);
    try {
      await completePasswordReset(oobCode, password);
      setSuccess(true);
    } catch (err) {
      setError(friendlyAuthError(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
        <View style={styles.logoBadge}>
          <Text style={styles.logoText}>A</Text>
        </View>
        <Text style={styles.title}>Choose a new password</Text>

        <View style={styles.card}>
          {!oobCode ? (
            <View style={{ alignItems: 'center' }}>
              <View style={[styles.banner, styles.bannerError, { alignSelf: 'stretch' }]}>
                <Text style={styles.bannerErrorText}>
                  This password reset link is invalid or has expired.
                </Text>
              </View>
              <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')}>
                <Text style={styles.linkText}>Request a new link</Text>
              </TouchableOpacity>
            </View>
          ) : success ? (
            <View style={{ alignItems: 'center' }}>
              <View style={[styles.banner, styles.bannerSuccess, { alignSelf: 'stretch' }]}>
                <Text style={styles.bannerSuccessText}>
                  Your password has been reset successfully.
                </Text>
              </View>
              <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                <Text style={styles.linkText}>Go to login</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <>
              {error ? (
                <View style={[styles.banner, styles.bannerError]}>
                  <Text style={styles.bannerErrorText}>{error}</Text>
                </View>
              ) : null}

              <Text style={styles.label}>New password</Text>
              <TextInput
                style={styles.input}
                value={password}
                onChangeText={setPassword}
                placeholder="At least 6 characters"
                secureTextEntry
              />

              <Text style={styles.label}>Confirm new password</Text>
              <TextInput
                style={styles.input}
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                secureTextEntry
              />

              <TouchableOpacity
                style={[styles.button, submitting && styles.buttonDisabled]}
                onPress={handleSubmit}
                disabled={submitting}
              >
                {submitting ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.buttonText}>Save new password</Text>
                )}
              </TouchableOpacity>
            </>
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
