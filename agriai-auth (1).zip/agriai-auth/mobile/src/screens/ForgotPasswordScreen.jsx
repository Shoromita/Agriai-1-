import { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { styles } from '../styles';

export default function ForgotPasswordScreen({ navigation, route }) {
  const { resetPassword } = useAuth();

  const [email, setEmail] = useState(route.params?.email || '');
  const [sent, setSent] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit() {
    if (!email) return;
    setSubmitting(true);
    try {
      await resetPassword(email);
    } catch {
      // Don't reveal whether the email exists in the system.
    } finally {
      setSent(true);
      setSubmitting(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
        <View style={styles.logoBadge}>
          <Text style={styles.logoText}>A</Text>
        </View>
        <Text style={styles.title}>Reset your password</Text>
        <Text style={styles.subtitle}>We'll email you a link to choose a new one</Text>

        <View style={styles.card}>
          {sent ? (
            <View style={{ alignItems: 'center' }}>
              <View style={[styles.banner, styles.bannerSuccess, { alignSelf: 'stretch' }]}>
                <Text style={styles.bannerSuccessText}>
                  If an account exists for {email}, a reset link has been sent. Check your
                  inbox, tap the link, and it will bring you back to this app to set a new
                  password.
                </Text>
              </View>
              <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                <Text style={styles.linkText}>Back to login</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <>
              <Text style={styles.label}>Email</Text>
              <TextInput
                style={styles.input}
                value={email}
                onChangeText={setEmail}
                placeholder="you@example.com"
                autoCapitalize="none"
                keyboardType="email-address"
              />

              <TouchableOpacity
                style={[styles.button, submitting && styles.buttonDisabled]}
                onPress={handleSubmit}
                disabled={submitting}
              >
                {submitting ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.buttonText}>Send reset link</Text>
                )}
              </TouchableOpacity>

              <View style={styles.linkRow}>
                <Text style={styles.bodyText}>Remembered it? </Text>
                <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                  <Text style={styles.linkText}>Back to login</Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
