import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { useAuth } from '../context/AuthContext';
import api from '../api/axios';
import { styles } from '../styles';

// Placeholder landing screen after login. Confirms the auth flow works end
// to end by fetching the MongoDB profile via GET /api/auth/me.
// AgriAI's real features (disease detection, weather, market prices) are out
// of scope for this build.
export default function DashboardScreen() {
  const { currentUser, logout } = useAuth();
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api
      .get('/auth/me')
      .then((res) => setProfile(res.data))
      .catch(() => setError('Could not load your profile.'));
  }, []);

  return (
    <View style={[styles.screen, { alignItems: 'center', justifyContent: 'center', padding: 24 }]}>
      <View style={[styles.card, { width: '100%', alignItems: 'center' }]}>
        <Text style={styles.title}>
          Welcome, {currentUser?.displayName || currentUser?.email}
        </Text>
        {profile && (
          <Text style={[styles.bodyText, { marginTop: 8 }]}>
            Signed in as {profile.role}
          </Text>
        )}
        {error ? <Text style={[styles.bannerErrorText, { marginTop: 8 }]}>{error}</Text> : null}
        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#1F2937', marginTop: 20, width: '100%' }]}
          onPress={logout}
        >
          <Text style={styles.buttonText}>Log out</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
