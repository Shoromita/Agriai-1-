import { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { friendlyAuthError } from '../utils/authErrors';
import { styles } from '../styles';

export default function LoginScreen({ navigation }) {
  const { login } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showResetLink, setShowResetLink] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit() {
    setError('');
    setShowResetLink(false);
    setSubmitting(true);

    try {
      await login(email, password);
      // onAuthStateChanged flips the root navigator to the app stack automatically
    } catch (err) {
      const message = friendlyAuthError(err);
      if (message === 'WRONG_CREDENTIALS') {
        setError('Incorrect email or password.');
        setShowResetLink(true);
      } else {
        setError(message);
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
        <View style={styles.logoBadge}>
          <Text style={styles.logoText}>A</Text>
        </View>
        <Text style={styles.title}>Welcome back</Text>
        <Text style={styles.subtitle}>Log in to your AgriAI account</Text>

        <View style={styles.card}>
          {error ? (
            <View style={[styles.banner, styles.bannerError]}>
              <Text style={styles.bannerErrorText}>{error}</Text>
              {showResetLink && (
                <TouchableOpacity
                  onPress={() => navigation.navigate('ForgotPassword', { email })}
                >
                  <Text style={[styles.linkText, { marginTop: 6 }]}>Reset your password</Text>
                </TouchableOpacity>
              )}
            </View>
          ) : null}

          <Text style={styles.label}>Email</Text>
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            placeholder="you@example.com"
            autoCapitalize="none"
            keyboardType="email-address"
          />

          <Text style={styles.label}>Password</Text>
          <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <View style={styles.linkRowEnd}>
            <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword', { email })}>
              <Text style={styles.linkText}>Forgot password?</Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={[styles.button, submitting && styles.buttonDisabled]}
            onPress={handleSubmit}
            disabled={submitting}
          >
            {submitting ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Log in</Text>
            )}
          </TouchableOpacity>

          <View style={styles.linkRow}>
            <Text style={styles.bodyText}>Don't have an account? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Signup')}>
              <Text style={styles.linkText}>Sign up</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
