import 'dotenv/config';

export default {
  expo: {
    name: 'AgriAI',
    slug: 'agriai',
    version: '1.0.0',
    orientation: 'portrait',
    scheme: 'agriai', // used for the reset-password deep link (agriai://reset-password)
    userInterfaceStyle: 'light',
    assetBundlePatterns: ['**/*'],
    ios: {
      supportsTablet: true,
      bundleIdentifier: 'com.agriai.app',
    },
    android: {
      package: 'com.agriai.app',
    },
    extra: {
      firebase: {
        apiKey: process.env.FIREBASE_API_KEY,
        authDomain: process.env.FIREBASE_AUTH_DOMAIN,
        projectId: process.env.FIREBASE_PROJECT_ID,
        storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
        messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
        appId: process.env.FIREBASE_APP_ID,
      },
      apiBaseUrl: process.env.API_BASE_URL,
      // Firebase bounces through this URL after the user taps "reset password"
      // in their inbox before redirecting into the app. See README.
      resetPasswordDeepLink: process.env.RESET_PASSWORD_DEEP_LINK,
    },
  },
};
