# AgriAI Mobile (React Native + Expo)

Same auth flow as the web client, built as a real phone app with Expo,
React Navigation, and the Firebase JS SDK. Uses the exact same `/server`
backend — nothing there changes.

## Prerequisites
- Node.js 18+
- The **Expo Go** app on your phone (App Store / Play Store) — easiest way
  to run this without setting up Xcode/Android Studio
- Your phone and computer on the **same Wi-Fi network**

## Setup

```bash
cd mobile
cp .env.example .env
```

Fill in `.env`:
- The `FIREBASE_*` values come from the same Firebase project as the web
  client (Project Settings > General > Your apps — the web app config works
  for the JS SDK on mobile too).
- `API_BASE_URL` — your computer's **LAN IP**, not `localhost` (a physical
  phone can't reach your computer's localhost). Find it with `ipconfig`
  (Windows) or `ifconfig`/`ipconfig getifaddr en0` (Mac). Example:
  `http://192.168.1.20:5000/api`.
- `RESET_PASSWORD_DEEP_LINK` — see "Deep linking" below.

```bash
npm install
npx expo start
```

Scan the QR code with the Expo Go app (Android: in-app scanner; iOS: Camera
app) to open AgriAI on your phone.

## Deep linking for password reset

Unlike the web app, there's no browser URL to land on. Firebase's reset
email link needs to bounce back into your app. Two working setups:

**During development (Expo Go):**
1. Run `npx expo start` and note the URL it prints, e.g.
   `exp://192.168.1.20:8081`.
2. Set `RESET_PASSWORD_DEEP_LINK=exp://192.168.1.20:8081/--/reset-password`
   in `.env`.
3. In Firebase Console > Authentication > Settings > Authorized domains,
   nothing extra is needed for Expo Go dev links — Firebase just needs a
   valid URL to redirect to, which then hands off to your app via `oobCode`
   in the query string.

**In a standalone/production build (EAS Build or `expo run:ios`/`android`):**
1. Use the custom scheme already configured in `app.config.js`:
   `RESET_PASSWORD_DEEP_LINK=agriai://reset-password`.
2. This only works once the app is actually installed on the device (the OS
   needs to know the `agriai://` scheme is claimed).

Either way, tapping the link in the reset email opens the app directly to
the **Reset Password** screen with the `oobCode` already in `route.params`.

## Notes / limitations
- If a user is already logged in and taps a reset-password link, the app
  currently routes to the logged-in stack (no Reset Password screen there).
  For this scope that's an acceptable edge case — solve it later by adding
  ResetPassword to both navigators if needed.
- `AsyncStorage` persists the Firebase session between app launches, so
  users stay logged in like a normal mobile app.
