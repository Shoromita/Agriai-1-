import { NavigationContainer } from '@react-navigation/native';
import * as Linking from 'expo-linking';
import { AuthProvider } from './src/context/AuthContext';
import RootNavigator from './src/navigation/RootNavigator';

// Maps incoming URLs (from the Firebase reset-password email, or any other
// deep link) to a screen + params. "agriai://reset-password?oobCode=..."
// -> ResetPassword screen with { oobCode } in route.params.
const linking = {
  prefixes: [Linking.createURL('/'), 'agriai://'],
  config: {
    screens: {
      Login: 'login',
      Signup: 'signup',
      ForgotPassword: 'forgot-password',
      ResetPassword: 'reset-password',
    },
  },
};

export default function App() {
  return (
    <AuthProvider>
      <NavigationContainer linking={linking}>
        <RootNavigator />
      </NavigationContainer>
    </AuthProvider>
  );
}
